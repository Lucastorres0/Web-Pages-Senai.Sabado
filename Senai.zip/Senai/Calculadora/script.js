var displayValue = ''; // Usada para armazenar a expressão matemática que é digitada na calculadora.

function numeros(value) { // Chamada sempre que um número ou operador é pressionado na calculadora. 
    displayValue += value; // Ela concatena o valor do botão pressionado
    document.getElementById('display').value = displayValue; // Atualiza o valor exibido no campo de texto no HTML 
}

function apagar() { // Essa função é responsável por limpar o valor da variável displayValue.
    displayValue = '';
    document.getElementById('display').value = displayValue;
}

function calcular() { // Nesta função, a expressão matemática armazenada em displayValue é avaliada usando a função eval().
    try {
        const result = eval(displayValue);
        document.getElementById('display').value = result;
        displayValue = result.toString();
    } catch (error) { // Se houver um erro durante a avaliação, a mensagem "Erro" será exibida no visor.
        document.getElementById('display').value = 'Erro';
    }
}

document.addEventListener("keydown", function(event) { // Cria um ouvinte de evento para capturar pressionamentos de tecla em todo o documento.
    const key = event.key; // Aqui, estamos obtendo a tecla pressionada do evento e armazenando-a na variável key.

    if (key.match(/[0-9+\-*/=C]/)) { // Este bloco verifica se a tecla pressionada é um número, um operador (+, -, *, /), "=", ou "C". Se for, executamos as ações correspondentes.
        event.preventDefault(); // Isso impede o comportamento padrão da tecla pressionada.

        if (key === "C") { // dependendo da tecla pressionada, a função apagar(), calcular() ou numeros(key) será chamada, executando assim as ações correspondentes.
            apagar();
        } else if (key === "=") {
            calcular();
        } else {
            numeros(key);
        }
    }
});

function backspace() {
    const lastCharacter = displayValue.slice(-1); // Pega o último caractere
    displayValue = displayValue.slice(0, -1);

    // Verifica se o último caractere era um dígito para remover somente ele
    if (lastCharacter.match(/[0-9]/)) {
        document.getElementById('display').value = displayValue;
    }
}